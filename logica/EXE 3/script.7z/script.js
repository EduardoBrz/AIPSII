let ht, vh, pd, sb, td, s1

ht = Number(prompt("voce trabalhou quantas horas no mes?"))
vh = Number(prompt("voce ganha quantos por horas trabalhada"))
pd = Number(prompt("qual o porcentual de desconto do seu salario:? "))
sb = ht * vh
td = (pd/100) * sb
s1 = sb - td

alert("horas trabalhadas = " + ht + " horas")
alert("salario bruto = R$" + sb)
alert("total desconto = R$" + td)
alert("salario liquido = R$" + s1)